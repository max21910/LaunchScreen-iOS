//
//  LaunchScreenXcodeApp.swift
//  LaunchScreenXcode
//
//  Created by Max  on 07/06/2022.
//

import SwiftUI

@main
struct LaunchScreenXcodeApp: App {
    var body: some Scene {
        WindowGroup {
            Prelaunch() //launch the app to the Launchscreen View
        }
    }
}

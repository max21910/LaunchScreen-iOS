# LaunchScreen-SwiftUI
[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/made-with-swift.svg)](https://forthebadge.com)

## Support :
📱 works from iOS 14 
## Who made this :
Made with ❤️ by Max21910 in 🇫🇷
## Description
A simple exemple of a launching screen made of 100% using SwiftUI 


## Free to use ?
yes this project is open source 

## Image :
![This is an image](img/Vid1.gif)

![This is an image](img/Vid2.gif)
## Support White mode: 
![This is an image](img/2.png)
## and Dark mode :
![This is an image](img/1.png)

